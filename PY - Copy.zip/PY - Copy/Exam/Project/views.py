from django.shortcuts import render, redirect
from .forms import UserForm
from .models import User
from django.contrib import messages

def register_user(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            # Create a new User object with the form data
            user = User(username=form.cleaned_data['username'], email=form.cleaned_data['email'], password=form.cleaned_data['password'])
            user.save()
            # Redirect the user to a success page
            return redirect('registration_success')
    else:
        form = UserForm()
    return render(request, 'Index.html', {'form': form})
